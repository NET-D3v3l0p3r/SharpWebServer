﻿using SharpWebServer.Ini;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpWebServer.Global
{
    public static class GlobalShares
    {
        public static INIParserI INIParser;
    }
}
